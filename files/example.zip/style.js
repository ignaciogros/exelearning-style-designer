/*!
 * eXeLearning v4.0.4 Example Style Script File
 * -----------------------
 * Author: Ignacio Gros
 * Project: eXeLearning.net
 *
 * This JavaScript file is part of a style for eXeLearning.
 * Licensed under Creative Commons Attribution-ShareAlike (CC BY-SA).
 *
 * Note: The style's config.xml contains additional information
 *       about materials (images, fonts, etc.) created by third parties
 *       and included in this style.
 */

var exampleStyle = {
    // Settings
    // 'web' | true | false
    darkModeToggler: 'web',
    init: function () {
        // Common functions
        if (this.inIframe()) $('body').addClass('in-iframe');
        // Dark mode
        var isWebSite = $('body').hasClass('exe-web-site');
        var darkMode = this.darkModeIn(isWebSite) && this.isLocalStorageAvailable();
        if (!darkMode) $('html').removeClass('exe-dark-mode');
        var togglers = '';
        if (darkMode) {
            togglers =
                '\
                <button type="button" id="darkModeToggler" class="toggler" aria-pressed="' +
                ($('html').hasClass('exe-dark-mode') ? 'true' : 'false') +
                '" title="' +
                $exe_i18n.mode_toggler +
                '">\
                    <span>' +
                $exe_i18n.mode_toggler +
                '</span>\
                </button>\
            ';
        }
        // Website only from here on
        if (!isWebSite) {
            if (darkMode) {
                $('.package-header').prepend(togglers);
                this.darkMode.init();
            }
            return;
        }
        // Add menu and search bar togglers
        togglers +=
            '\
            <button type="button" id="siteNavToggler" class="toggler" aria-expanded="true" aria-controls="siteNav" title="' +
            $exe_i18n.menu +
            '">\
                <span>' +
            $exe_i18n.menu +
            '</span>\
            </button>\
            <button type="button" id="searchBarToggler" class="toggler" aria-expanded="false" aria-controls="exe-client-search" title="' +
            $exe_i18n.search +
            '">\
                <span>' +
            $exe_i18n.search +
            '</span>\
            </button>\
        ';
        $('#siteNav').before(togglers);
        // Check the current NAV status
        if (new URLSearchParams(window.location.search).get('nav') === 'false') {
            $('body').addClass('siteNav-off');
            exampleStyle.navExpanded(false);
            exampleStyle.params('add');
        }
        // Dark mode
        this.darkMode.init();
        // Menu toggler
        $('#siteNavToggler').on('click', function () {
            if (exampleStyle.isLowRes()) {
                $('#exe-client-search').hide();
                $('#searchBarToggler').attr('aria-expanded', 'false');
                if ($('body').hasClass('siteNav-off')) {
                    $('body').removeClass('siteNav-off');
                    exampleStyle.navExpanded(true);
                    exampleStyle.params('remove');
                } else {
                    if ($('#siteNav').isInViewport()) {
                        $('body').addClass('siteNav-off');
                        exampleStyle.navExpanded(false);
                        exampleStyle.params('add');
                    }
                }
                window.scroll(0, 0);
            } else {
                $('body').toggleClass('siteNav-off');
                var off = $('body').hasClass('siteNav-off');
                exampleStyle.navExpanded(!off);
                exampleStyle.params(off ? 'add' : 'remove');
            }
        });
        // Search bar toggler
        $('#searchBarToggler').on('click', function () {
            var bar = $('#exe-client-search');
            if (bar.is(':visible')) {
                bar.hide();
                $(this).attr('aria-expanded', 'false');
            } else {
                if (exampleStyle.isLowRes()) {
                    $('body').addClass('siteNav-off');
                    exampleStyle.navExpanded(false);
                    exampleStyle.params('add');
                }
                bar.show();
                $(this).attr('aria-expanded', 'true');
                $('#exe-client-search-text').trigger('focus');
                window.scroll(0, 0);
            }
        });
        // Search form
        this.searchForm();
    },
    darkModeIn: function (isWebSite) {
        if (!this.darkModeToggler) return false;
        if (this.darkModeToggler === 'web') return isWebSite;
        return true;
    },
    isLocalStorageAvailable: function () {
        var x = '';
        try {
            localStorage.setItem(x, x);
            localStorage.removeItem(x);
            return true;
        } catch (e) {
            return false;
        }
    },
    darkMode: {
        init: function () {
            $('#darkModeToggler').on('click', function () {
                var active = $('html').hasClass('exe-dark-mode') ? 'off' : 'on';
                exampleStyle.darkMode.setMode(active);
                $(this).attr('aria-pressed', active == 'on' ? 'true' : 'false');
            });
        },
        read: function () {
            try {
                return localStorage.getItem('exeDarkMode');
            } catch (e) {
                return null;
            }
        },
        write: function (value) {
            try {
                if (value) localStorage.setItem('exeDarkMode', value);
                else localStorage.removeItem('exeDarkMode');
            } catch (e) {}
        },
        setMode: function (active) {
            var dark = exampleStyle.darkMode.read() == 'on';
            if (active) dark = active == 'on';
            exampleStyle.darkMode.write(dark ? 'on' : null);
            $('html').toggleClass('exe-dark-mode', dark);
        }
    },
    inIframe: function () {
        try {
            return window.self !== window.top;
        } catch (e) {
            return true;
        }
    },
    searchForm: function () {
        $('#exe-client-search-text').attr('class', 'form-control');
    },
    isLowRes: function () {
        return $('#siteNav').css('position') == 'static';
    },
    navExpanded: function (visible) {
        $('#siteNavToggler').attr('aria-expanded', visible ? 'true' : 'false');
    },
    params: function (act) {
        var value = act == 'add' ? 'false' : null;
        $('.nav-buttons a').each(function () {
            this.setAttribute(
                'href',
                $exeExport.setUrlParam(this.getAttribute('href'), 'nav', value)
            );
        });
    }
};
$(function () {
    exampleStyle.init();
});
exampleStyle.darkMode.setMode();
$.fn.isInViewport = function () {
    var elementTop = $(this).offset().top;
    var elementBottom = elementTop + $(this).outerHeight();
    var viewportTop = $(window).scrollTop();
    var viewportBottom = viewportTop + $(window).height();
    return elementBottom > viewportTop && elementTop < viewportBottom;
};
